<!DOCTYPE html>
<?php
 session_start();
 $login_msg=NULL;
if(isset($_POST['login'])){
  include_once('attach_file/mysql.php');
  $sql = "SELECT * FROM `login` WHERE username='$_POST[USERNAME]' AND pass='$_POST[password]' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $_SESSION["userid"]=$row["user_id"];
      $_SESSION["user"] = $_POST["USERNAME"];
      $_SESSION["pass"] = $_POST["password"];
        header('location:dashboard.php');
} else {
    $login_msg="YOU RETURN WRONG USERNAME OR PASSWORD";
}
}
 ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>EXAM REGISTORY</title>
    <link rel="stylesheet" href="css/main.css">
  </head>
  <body>
    <form class="form" action="" method="post">
      <div class="form_box">
        <p class="head_txt">SIGN IN</p>
        <label for="">USERNAME:</label><br>
<input type="text" name="USERNAME" value="" placeholder="USERNAME" >
 </div>
 <div class="form_box">
   <label for="">PASSWORD:</label><br>
<input type="password" name="password" value="" placeholder="PASSWORD">
 </div>
 <?php  echo "<br>".$login_msg;?>
 <button type="submit" name="login" class="button">SIGN IN</button>
    </form>
  </body>
</html>
