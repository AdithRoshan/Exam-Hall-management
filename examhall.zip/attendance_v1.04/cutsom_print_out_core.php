<!DOCTYPE html>
<?php include 'attach_file/mysql.php';
$resultsa=1;
$sql = "SELECT * FROM seat_formation LEFT JOIN
 examhall ON seat_formation.hall_id = examhall.exam_hall_id
 WHERE attendance='ABSENTS' AND hall_id=$_GET[examhall] AND date='$_GET[date]' ";
//echo $sql;
$result = $conn->query($sql);
	if ($result->num_rows > 0) {
 ?>
<html>
<head>
	<title>HTML to PDF</title>
</head>
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/mian.css">
<body>

	<div id="HTMLtoPDF">

	<h2>ABC UNIVERSITY</h2>
	<h4>Date of Examination:  <?php echo $_GET['date']; ?> </h4>
	<h4>Center of Examination: ABC college</h4>
    <table>
      <tr>
        <td>Reg No</td>
        <td>Absecented Students</td>
      </tr>
  <?php
	 while($row = $result->fetch_assoc()) { ?>
     <tr>
       <td><?php echo $row["student_id"]; ?></td>
         <td></td>
     </tr>
      <?php
   }
 }else {
   echo "no Results to be Displays";
   $resultsa=0;
 }
   ?>
  </table>
	</div>

<?php if ($resultsa==1) {?>
  	<a href="#" onclick="HTMLtoPDF()">Download PDF</a>
  <?php
}
else {
  ?>
    	<a href="dashboard.php" >Go Back to Home</a>
  <?php
}?>


	<script src="js/jspdf.js"></script>
	<script src="js/jquery-2.1.3.js"></script>
	<script src="js/pdfFromHTML.js"></script>
</body>
</html>
