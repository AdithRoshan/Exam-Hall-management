
//form creation function for dashdorad default and Exam Hall
  function create_model_content(para) {
    form_loading("Dashboard");
  }
        create_model_content({placeholder: create_names, name: create_head_name});
        //function for animation of veiwing model dropdown and button rotation
  var type=0;
function model() {
  if (type==0) {
    document.getElementById('round').style.transform="rotate(-230deg)";
    document.getElementById('model').style.top="120px";
    type=1;
  }else {
    registor_table_call();
    document.getElementById('round').style.transform="rotate(0deg)";
    document.getElementById('model').style.top="-2000px";
    type=0;
  }
}


//XMLHttpRequest for get create form of program course and timetable
function form_loading(form_type,table_name=0,id_no=0) {
  var url_name="attach_file/create_form.php?type="+form_type;
if (table_name!=0) {
  url_name=url_name+"&button_type="+table_name+"&id_no="+id_no;
}
  //console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("model_inputs").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}


//edit_all date on table
function edit_table(id_no, table_name) {
  console.log(table_name);
  if (table_name=="department") {
    form_loading("Dashboard",table_name,id_no)
  }
  if (table_name=="examhall") {
    form_loading("Exam_hall",table_name,id_no);
  }
  if (table_name=="program") {
    form_loading("program",table_name,id_no);
  }
  if (table_name=="program") {
    form_loading("program",table_name,id_no);
  }
  if (table_name=="course") {
    form_loading("course",table_name,id_no);
  }
  if (table_name=="timetable") {
    form_loading("time_table",table_name,id_no);
  }
//  form_loading("Dashboard");
model();
}
function delete_table(id_no, table_name){
  var url_name="attach_file/delete_table.php?type=delete&id_no="+id_no+"&table_name="+table_name;

  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("create_status").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
      registor_table_call();
}

function form_loading1(form_type) {
  var url_name="attach_file/create_form.php?type="+form_type;

  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("model_inputs1").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}

var type1=0
function course_adder() {
      form_loading1("course_student_adder");
    document.getElementById('model1').style.top="120px";
}
function course_adder_close() {
document.getElementById('model1').style.top="-2000px";
}
function seatarragment() {
  document.getElementById('model2').style.top="120px";
}
function seatarragment_close() {
  document.getElementById('model2').style.top="-2000px";
}

function create_seat_arragment() {
  var url_name="attach_file/seat_arragment.php?date="+document.getElementById("arragement_date").value;
var url_name=url_name+"&time="+document.getElementById("time").value;
  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("create_status2").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
function attendance() {
    document.getElementById('model3').style.top="120px";
}
function attendance_close() {
    document.getElementById('model3').style.top="-2000px";
}

function attendance_odinary() {
  var url_name="attach_file/attendance.php?date="+document.getElementById("arragement_date1").value;
var url_name=url_name+"&time="+document.getElementById("time1").value;
url_name=url_name+"&room="+document.getElementById("room_number").value;
  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("create_status3").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}

function attendance_room_option() {
  var url_name="attach_file/option_room.php?date="+document.getElementById("arragement_date1").value;
 url_name=url_name+"&time="+document.getElementById("time1").value;

  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("option_hall3").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}

function print_formation() {
      document.getElementById('print_formation').style.top="120px";
}
function print_close() {
      document.getElementById('print_formation').style.top="-2000px";
}
function attendance_printout() {
  console.log('in');
  url_name='attach_file/print_attendance.php';
  document.getElementById('formation_print_model').style.top="120px";
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("atteandence_formation_printout").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}

function exam_date() {
  document.getElementById('update_exam_date').style.top="120px";
  url_name='attach_file/update_exam_date.php';
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("update_exam_date_selector").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
function exam_history() {
  document.getElementById('exam_history_model').style.top="120px";
  url_name='attach_file/exam_history_viewrs.php';
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("exam_history_model_sector").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
function show_historys(val) {
url_name='attach_file/exam_history_table_viewers.php?values='+val;
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    document.getElementById("sector_show_history").innerHTML =
    this.responseText;
  }
};
xhttp.open("GET", url_name, true);
xhttp.send();
}
function History_close() {
    document.getElementById('exam_history_model').style.top="-20000px";
}
