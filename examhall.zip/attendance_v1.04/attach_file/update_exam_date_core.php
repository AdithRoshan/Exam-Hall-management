<?php
include 'mysql.php';
$sql = "SELECT * FROM timetable WHERE pcode='$_GET[papercode]'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
       $Previous_date=$row["exam_date"];
    }
} else {
    echo "0 results";
}

$sql = "UPDATE timetable SET exam_date='$_GET[paperDate]' WHERE pcode='$_GET[papercode]'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$sql = "INSERT INTO updated_timetable
(update_paper_codes, time_table_history)
VALUES ('$_GET[papercode]', '$Previous_date')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location: /attendance_v1.04/dashboard.php"); 
 ?>
