<!DOCTYPE html>
<?php include 'mysql.php';
$sql = "SELECT * FROM timetable";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="attach_file/update_exam_date_core.php" method="get">
<label for="">Exam Paper Code</label>
<select class="" name="papercode" id='papercode'>
  <?php  while($row = $result->fetch_assoc()) { ?>
  <option value="<?php echo $row['pcode']; ?>"><?php echo $row['pcode']; ?></option>
  <?php     }
} else {
    echo "0 results";
} ?>
</select><br>
<label for="">Select the Date</label>
<input type="date" name="paperDate" value="" id="paperDate"><br>
<button type="submit" name="button">Submit</button>
    </form>
  </body>
</html>
