<nav>
  <div class="left nav_head">
    EXAM PORTAL
  </div>
  <div class="right user_btn">
    User
  </div>
  <a href="logout.php"> <div class="right btn_sign_out">
    Sign out
  </div></a>
  <div class="right btn_sign_out" onclick="seatarragment()">
    Seat Arrangement
  </div>
  <div class="right btn_sign_out" onclick="attendance()">
    Attendance
  </div>
    <div class="right btn_sign_out" onclick="print_formation()">
      Print Formation
    </div>
    <div class="right btn_sign_out" onclick="custom_formation()">
      Custom Formation
    </div>
    <div class="right btn_sign_out" onclick="attendance_printout()">
      Attendance PrintOut
    </div>
    <div class="right btn_sign_out" onclick="exam_date()">
      Change Exam Date
    </div>
    <div class="right btn_sign_out" onclick="exam_history()">
      Exam History
    </div>
</nav>
