<?php
include 'mysql.php';
$sql = "SELECT * FROM seat_formation WHERE date = '$_GET[date]'  AND time= '$_GET[time]' AND hall_id=$_GET[room] ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {?>
      <input type="checkbox" name="vehicle1" id="<?php echo $row["student_id"]; ?>"value="<?php echo $row["student_id"]; ?>" onclick="select_option_checkbox(this.id)">Roll no: <?php echo $row["student_id"]; ?>
  <?php  }
} else {
    echo "0 results";
}
 ?>
