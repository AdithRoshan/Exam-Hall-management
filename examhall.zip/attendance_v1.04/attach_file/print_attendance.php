<!DOCTYPE html>
<?php
include 'mysql.php';
$sql = "SELECT * FROM examhall";
$result = $conn->query($sql);
 ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="cutsom_print_out_core.php" method="get">
      <label for="">Date:</label>
      <input type="date" name="date" value="" id="">
      <br>
      <label for="">Time</label>
      <select class="" name="time" id="time">
      <option value="FN">FN</option>
      <option value="AN">AN</option>
      </select>
      <br>
      <?php
      if ($result->num_rows > 0) {
        $count=0;
          while($row = $result->fetch_assoc()) {
            //  echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
            ?>
      <input type="radio" name="examhall" id="examhall<?php echo $count; ?>" value="<?php echo $row["exam_hall_id"]; ?>"><?php echo $row["hall_no"]; ?><br>
        <?php
         $count++; }
      } else {
          echo "0 results";
      } ?>
      <button type="submit" name="button">Submit</button>
    </form>

  </body>
</html>
