<?php
class view_table {
 var $table_name;
 var $table_head;
 var $sql_qery_select="SELECT";
 var $table_data;
 var $count=0;
 var $colomn;
 var $table_name_list;
public function insert()
{
  if (isset($_GET['table_name'])) {
      $this->table_name=$_GET["table_name"];
  }
  else {
    $this->table_name=$_GET["table_name_list"][0];
  }
  $this->table_head=$_GET["table_head"];
}
public function row_query_merger($value='')
{
    if (isset($_GET['table_name'])) {
  for ($i=0; $i < count($this->table_head); $i++) {
    if ($i==0) {
        $this->sql_qery_select= $this->sql_qery_select.' '.$this->table_head[$i];
    }
    else {
        $this->sql_qery_select= $this->sql_qery_select.','.$this->table_head[$i];
    }
  }
    $this->sql_qery_select= $this->sql_qery_select." FROM ".$this->table_name;
}
else {
  $this->table_name_list=$_GET['table_name_list'];
  $this->sql_qery_select="SELECT * FROM ".$this->table_name;
  $count=0;
  for ($i=1; $i < count($this->table_name_list); $i++) {
    $this->sql_qery_select=$this->sql_qery_select." LEFT JOIN";
    $this->sql_qery_select=$this->sql_qery_select." ".$this->table_name_list[$i];
    $this->sql_qery_select=$this->sql_qery_select." ON";
    $this->sql_qery_select=$this->sql_qery_select." ".$_GET["table_joint_parameter"][$count];
    $count++;
  }
 //echo $this->sql_qery_select;
}

}

public function select_query()
{
  include 'mysql.php';
  $sql = "$this->sql_qery_select";
  $result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      for ($i=0; $i < count($this->table_head); $i++) {
        $this->table_data[$i][$this->count]=$row[$this->table_head[$i]];
        //echo $this->table_data[$i][$this->count];
        //echo "<br>";
      //  echo $this->count;
        //echo $i;
      }
      $this->count++;
      $this->colomn=$i;
    }
} else {
    echo "0 results";
}
//echo $this->table_data[1][2];
}
}
  $select = new view_table;
  $select->insert();
  $select->row_query_merger();
  $select->select_query();
 ?>
 <table>
<tr class="head_table">
  <td></td>
  <td></td>
      <?php for ($i=0; $i < count($_GET["table_alter_head_name"]); $i++) {?>
  <td><?php echo $_GET["table_alter_head_name"][$i]; ?></td><?php  } ?>
        </tr>
        <?php for ($i=0; $i < $select->count; $i++) { ?>
          <tr class="rows">
            <td>  <button type="button" name="button" onclick="delete_table('<?php echo$select->table_data[0][$i]; ?>','<?php echo   $select->table_name; ?>')">Delete</button> </td>
            <td>  <button type="button" name="button" onclick="edit_table('<?php echo$select->table_data[0][$i]; ?>','<?php echo   $select->table_name; ?>')">Edit</button> </td>
            <?php for ($j=0; $j < $select->colomn; $j++) { ?>
      <td> <?php echo$select->table_data[$j][$i]; ?> </td>
      <?php  } ?>
      </tr>
      <?php  } ?>
</table>
