<?php
if (isset($_GET['type'])) {
  function sql_update_query($sql_query_update)
  {
      include 'mysql.php';
    $sql = $sql_query_update;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

  }
  function sql_query_insert($table_name,$update_value,$id_no,$update_row_name,$where_row_name,$charc="no")
  {
    $sql="UPDATE ".$table_name." SET ".$update_row_name." = ' ".$update_value." ' WHERE ".$where_row_name." = ".$id_no;
    if ($charc=="yes") {
      $sql="UPDATE ".$table_name." SET ".$update_row_name." = '".$update_value."' WHERE ".$where_row_name." = '".$id_no."'";
    }
    echo $sql;
    sql_update_query($sql);
  }
  if ($_GET['type']=="edit") {
    if ($_GET['table_name']=="Dashboard") {
      sql_query_insert($_GET['button_type'], $_GET['department_name'],$_GET['id_no'],"deptname","dpt_id");
    }
    if ($_GET['table_name']=="Exam_hall") {
      sql_query_insert($_GET['button_type'], $_GET['hall_no'],$_GET['id_no'],"hall_no","exam_hall_id");
      sql_query_insert($_GET['button_type'], $_GET['capacity'],$_GET['id_no'],"capacity","exam_hall_id");
    }
    if ($_GET['table_name']=="program") {
      sql_query_insert($_GET['button_type'], $_GET['program_name'],$_GET['id_no'],"prgmname","pgrmid");
     sql_query_insert($_GET['button_type'], $_GET['department_id'],$_GET['id_no'],"deptid","pgrmid");
    }
    if ($_GET['table_name']=="course") {
      sql_query_insert($_GET['button_type'], $_GET['paper_code'],$_GET['id_no'],"pcode","pcode","yes");
     sql_query_insert($_GET['button_type'], $_GET['semester'],$_GET['id_no'],"semester","pcode","yes");
     sql_query_insert($_GET['button_type'], $_GET['batch'],$_GET['id_no'],"batch","pcode","yes");
     sql_query_insert($_GET['button_type'], $_GET['programid'],$_GET['id_no'],"pgrmid","pcode","yes");
    }
    if ($_GET['table_name']=="time_table") {
  sql_query_insert($_GET['button_type'], $_GET['exam_date'],$_GET['id_no'],"exam_date","pcode","yes");
    sql_query_insert($_GET['button_type'], $_GET['Time'],$_GET['id_no'],"time","pcode","yes");
        sql_query_insert($_GET['button_type'], $_GET['timetable'],$_GET['id_no'],"pcode","pcode","yes");
    }
  }
}
 ?>
