<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<?php
include 'mysql.php';
$sql = "SELECT * FROM updated_timetable WHERE update_paper_codes='$_GET[values]'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo  $row["time_table_history"];
        echo "<br>";
    }
} else {
    echo "No History For this Paper Code is been Recorded";
}
 ?>
</body>
</html>
