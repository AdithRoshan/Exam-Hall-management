<div class="left secound_nav">
  <div class="option active" onclick="table_changer('Dashboard')" id="Dashboard">
     Dashboard
  </div>
  <div class="option " onclick="table_changer('Exam_hall')" id="Exam_hall">
     Exam Hall
  </div>
  <div class="option " onclick="table_changer('program')" id="programnav">
     Program
  </div>
  <div class="option " onclick="table_changer('course')" id="coursed">
     Course
  </div>
  <div class="option " onclick="table_changer('time_table')" id="time_table">
     Time Table
  </div>
  <div class="option " onclick="table_changer('student_reg')" id="student_reg">
     Register Student
  </div>
</div>
<script type="text/javascript">
function table_changer(table_set) {
  if (table_set=='Dashboard') {
    document.getElementById('Dashboard').className="option active";
    document.getElementById('Exam_hall').className="option";
    document.getElementById('programnav').className="option";
    document.getElementById('coursed').className="option";
    document.getElementById('time_table').className="option";
    document.getElementById('student_reg').className="option";
     head_name=["dpt_id","deptname"];
      table_name=["department"];
        table_alter_head_name=["Id","department"];
         create_names=["department name"];
         create_head_name=["deptname"];
               form_loading('Dashboard');
         loadDoc({head_names: head_name,table_name: table_name, table_alter_head_name: table_alter_head_name});
  }
  else if (table_set=='Exam_hall') {
    document.getElementById('Dashboard').className="option";
    document.getElementById('Exam_hall').className="option active";
    document.getElementById('programnav').className="option";
    document.getElementById('coursed').className="option";
    document.getElementById('time_table').className="option";
    document.getElementById('student_reg').className="option";
     head_name=["exam_hall_id","hall_no","capacity"];
     table_name=["examhall"];
     table_alter_head_name=["exam_hall_id","Hall no","capacity"];
     create_names=["Hall No","apacity"];
    create_head_name=["hall_no","capacity"];
      form_loading('Exam_hall');
       loadDoc({head_names: head_name,table_name: table_name, table_alter_head_name: table_alter_head_name});
  }else if (table_set=='program') {
    document.getElementById('Dashboard').className="option";
    document.getElementById('Exam_hall').className="option ";
    document.getElementById('programnav').className="option active";
    document.getElementById('coursed').className="option";
    document.getElementById('time_table').className="option";
    document.getElementById('student_reg').className="option";
     head_name=["pgrmid","prgmname","deptname"];
     table_namelist=["program","department"];
     joint_parameters=["program.deptid = department.dpt_id"];
     table_alter_head_name=["Id","program name","department"];
     form_loading('program');
       loadDoc({head_names: head_name,table_namelist: table_namelist, table_alter_head_name: table_alter_head_name, joint_parameters:joint_parameters  });
  }else if (table_set=='course') {
    document.getElementById('Dashboard').className="option";
    document.getElementById('Exam_hall').className="option ";
    document.getElementById('programnav').className="option ";
    document.getElementById('coursed').className="option active";
    document.getElementById('time_table').className="option";
    document.getElementById('student_reg').className="option";
    head_name=["pcode","semester","batch","prgmname","deptname"];
    table_namelist=["course","program","department"];
    joint_parameters=["course.pgrmid = program.pgrmid " , "program.deptid = department.dpt_id"];
    table_alter_head_name=["Paper code","Semester","Batch","Program name","Department name"];
    form_loading('course');
     loadDoc({head_names: head_name,table_namelist: table_namelist, table_alter_head_name: table_alter_head_name, joint_parameters:joint_parameters });
  }else if (table_set=='time_table') {
    document.getElementById('Dashboard').className="option";
    document.getElementById('Exam_hall').className="option ";
    document.getElementById('programnav').className="option ";
    document.getElementById('coursed').className="option";
    document.getElementById('student_reg').className="option";
    document.getElementById('time_table').className="option active";
    head_name=["pcode","exam_date","time","semester","batch","prgmname","deptname"];
table_namelist=["timetable","course","program","department"];
joint_parameters=["timetable.pcode = course.pcode ","course.pgrmid = program.pgrmid " , "program.deptid = department.dpt_id"];
table_alter_head_name=["Paper Code","Exam Date","Time","Semester","Batch","Program Name","Department Name"];
form_loading('time_table');
 loadDoc({head_names: head_name,table_namelist: table_namelist, table_alter_head_name: table_alter_head_name, joint_parameters:joint_parameters });
}else if (table_set=='student_reg') {
  document.getElementById('Dashboard').className="option";
  document.getElementById('Exam_hall').className="option ";
  document.getElementById('programnav').className="option ";
  document.getElementById('coursed').className="option";
  document.getElementById('student_reg').className="option active";
  document.getElementById('time_table').className="option ";
  head_name=["st_id","student_name","semester","course","program"];
table_namelist=["student","student_detail"];
joint_parameters=["student.st_id = student_detail.student_id "];
table_alter_head_name=["Student Id","Student Name","Semester","Course","Program"];
  //create_names=["Hall No","apacity"];
 //create_head_name=["hall_no","capacity"];
   form_loading('student_reg');
 loadDoc({head_names: head_name,table_namelist: table_namelist, table_alter_head_name: table_alter_head_name, joint_parameters:joint_parameters });
}
  }
</script>
