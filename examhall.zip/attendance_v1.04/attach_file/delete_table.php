<?php
if (isset($_GET['type'])) {
  function query_added($delete_query_sql)
  {
    include 'mysql.php';
    $sql=$delete_query_sql;
    if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
  }
  function delete_query_sql($id_no,$row_id_name,$table)
  {
    $delete_query_table="DELETE FROM ".$table." WHERE $id_no='".$row_id_name."'";
    echo $delete_query_table;
    query_added($delete_query_table);
  }
if ($_GET['type']=="delete") {
  if ($_GET['table_name']=="timetable") {
    $id_no="pcode";
    $row_id_name=$_GET['id_no'];
    $table=$_GET['table_name'];
    delete_query_sql($id_no, $row_id_name, $table);
  }
    if ($_GET['table_name']=="course") {
      $id_no="pcode";
      $row_id_name=$_GET['id_no'];
      $table=$_GET['table_name'];
          delete_query_sql($id_no, $row_id_name, $table);
    }
    if ($_GET['table_name']=="program") {
      $id_no="pgrmid";
      $row_id_name=$_GET['id_no'];
      $table=$_GET['table_name'];
          delete_query_sql($id_no, $row_id_name, $table);
    }
    if ($_GET['table_name']=="examhall") {
      $id_no="exam_hall_id";
      $row_id_name=$_GET['id_no'];
      $table=$_GET['table_name'];
          delete_query_sql($id_no, $row_id_name, $table);
    }
    if ($_GET['table_name']=="department") {
      $id_no="dpt_id";
      $row_id_name=$_GET['id_no'];
      $table=$_GET['table_name'];
          delete_query_sql($id_no, $row_id_name, $table);
    }
    if ($_GET['table_name']=="student") {
      $id_no="st_id";
      $row_id_name=$_GET['id_no'];
      $table=$_GET['table_name'];
          delete_query_sql($id_no, $row_id_name, $table);
    }
}
?>
<script type="text/javascript">
  registor_table_call();
</script>
<?php
}

 ?>
