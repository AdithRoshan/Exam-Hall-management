<?php
include 'mysql.php';
$sql = "SELECT DISTINCT hall_id FROM seat_formation WHERE date = '$_GET[date]'  AND time= '$_GET[time]'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {?>
  <select class="" name="" id="room_number" onchange="attendance_odinary()">
    <option value="">choose option</option>
  <?php    while($row = $result->fetch_assoc()) {?>
      <option value="<?php echo $row["hall_id"]; ?>"><?php echo $row["hall_id"]; ?></option>
  <?php  }
  ?>      </select>
  <?php
} else {
    echo "0 results";
}
 ?>
