<?php
if (isset($_GET['type'])) {
  function sql_select_query($table_name, $row_name,$value_name)
  {
        include 'mysql.php';
    $query_sql='SELECT * FROM '.$table_name;
    $sql = "$query_sql";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
      $option_html=' <select id="'.$table_name.'" name="'.$table_name.'">  <option value="NULL" name="'.$table_name.'" >Choose the option</option>';
    while($row = $result->fetch_assoc()) {
      $option_html=$option_html.'<option value="'.$row[$value_name].'" > '.$row[$row_name].'</option>';
    }
    $option_html=$option_html.'</select>';
} else {
    echo "0 results";
    $option_html=0;
}
  echo $option_html;
  }

function sql_select_query_dist($table_name, $row_name,$value_name)
{
  include 'mysql.php';
$query_sql='SELECT DISTINCT semester FROM '.$table_name;
$sql = "$query_sql";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$option_html=' <select id="'.$table_name.'" name="'.$table_name.'">  <option value="NULL" name="'.$table_name.'" >Choose the option</option>';
while($row = $result->fetch_assoc()) {
$option_html=$option_html.'<option value="'.$row[$value_name].'" > '.$row[$row_name].'</option>';
}
$option_html=$option_html.'</select>';
} else {
echo "0 results";
$option_html=0;
}
echo $option_html;
}

function sql_select_query_onchange($table_name, $row_name,$value_name)
{
  include 'mysql.php';
$query_sql='SELECT * FROM '.$table_name;
$sql = "$query_sql";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$option_html=' <select id="'.$table_name.'" name="'.$table_name.'" onchange="selectbar_change('.$table_name.')">  <option value="NULL" name="'.$table_name.'" >Choose the option</option>';
while($row = $result->fetch_assoc()) {
$option_html=$option_html.'<option value="'.$row[$value_name].'" > '.$row[$row_name].'</option>';
}
$option_html=$option_html.'</select>';
} else {
echo "0 results";
$option_html=0;
}
echo $option_html;
}

if ($_GET['type']=="Dashboard") {?>
  <input type="text" name="" value="" class="input" id="department_name" placeholder="Department name">
  <?php
}
if ($_GET['type']=="student_reg") {?>
  <input type="text" name="" value="" class="input" id="student_name" placeholder="student name">
    <br>  <label for="">Semester</label>
    <?php sql_select_query_dist("course","semester","semester");?>
    <br>  <label for="">Course</label>
    <?php sql_select_query_onchange("program","prgmname","prgmname");?>
    <br>  <label for="">Department</label>
    <?php sql_select_query("department","deptname","deptname");?>
<?php
}
if ($_GET['type']=="Exam_hall") {?>
  <input type="text" name="" value="" class="input" id="hall_no" placeholder="Hall no">
  <input type="text" name="" value="" class="input" id="capacity" placeholder="Capacity">
  <?php
}

  if ($_GET['type']=='program') {?>
    <input type="text" name="" value="" class="input" id="program_name" placeholder="Program name">
  <br>  <label for="">Department</label>
    <?php
    sql_select_query("department","deptname","dpt_id");
  }
  if ($_GET['type']=='course') {?>
    <input type="text" name="" value="" class="input" id="paper_code" placeholder="Paper Code">
        <input type="text" name="" value="" class="input" id="semester" placeholder="Semester">
            <input type="number" name="" value="" class="input" id="batch" placeholder="Batch">
            <br>  <label for="">Program</label>
            <?php sql_select_query("program","prgmname","pgrmid");?>
    <?php// sql_select_query("department","deptname","dpt_id");?>

    <?php
  }

  if ($_GET['type']=='time_table') {?>
    <label for="">Date</label>
    <input type="date" name="" value="" class="input" id="exam_date" placeholder="exam date">
  <br>  <label for="">Exam Time</label>
  <select class="" name="" id="Time">
    <option value="NULL">choose the option</option>
    <option value="FN">FN</option>
    <option value="AN">AN</option>
  </select>
  <br>  <label for="">Paper Code</label>
    <?php
    sql_select_query("course","pcode","pcode");
  }?>
  <?php
if ($_GET['type']=='course_student_adder') {
?>
<input type="number" name="" value="" class="input" id="student_id" placeholder="student id">
  <br>  <label for="">Semester</label>
      <?php sql_select_query("course","semester","semester");?>
      <br>  <label for="">Course</label>
      <?php sql_select_query("program","prgmname","prgmname");?>
      <br>  <label for="">Department</label>
      <?php sql_select_query("department","deptname","deptname");?>

<?php
}
   ?>
  <br>
  <?php if (isset($_GET['button_type']) ) {?>
      <button type="button" name="button" class="btn" id="" onclick="create_table('<?php echo $_GET['type']; ?>','<?php echo $_GET['button_type']; ?>','<?php echo $_GET['id_no']; ?>')">SUBMIT</button>
    <?php
  } else {?>
  <button type="button" name="button" class="btn" id="" onclick="create_table('<?php echo $_GET['type']; ?>')">SUBMIT</button>
<?php  }?>

  <?php
}
 ?>
