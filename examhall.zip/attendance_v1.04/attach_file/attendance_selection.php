<?php
include 'mysql.php';
$sql = "UPDATE seat_formation SET attendance='ABSENTS' WHERE date='$_GET[date]' AND time='$_GET[time]' AND hall_id=$_GET[hall_no] AND student_id=$_GET[roll_number]";

if ($conn->query($sql) === TRUE) {
} else {
    echo "Error updating record: " . $conn->error;
}
 ?>
