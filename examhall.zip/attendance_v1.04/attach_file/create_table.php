<?php

class create_table
{
  var $query_sql="INSERT INTO ";
  public function sql_query_builder($table_name,$row_name,$row_value)
  {
    $this->query_sql=$this->query_sql.$table_name." ( ";
    for ($i=0; $i < count($row_name); $i++) {
      $this->query_sql=$this->query_sql.$row_name[$i];
      if(count($row_name)-1!=$i){
        $this->query_sql=$this->query_sql.", ";
      }
    }
      $this->query_sql=$this->query_sql." ) VALUES ( ";
      for ($i=0; $i < count($row_value); $i++) {
          $this->query_sql=$this->query_sql."'".$row_value[$i]."'";
          if(count($row_name)-1!=$i){
            $this->query_sql=$this->query_sql.", ";
          }
      }
      $this->query_sql=$this->query_sql.")";
   //echo $this->query_sql;
  }

public function sql_added_to_table()
{
    include 'mysql.php';
  $sql =$this->query_sql;
  if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
}
else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}
}

public function max_cont($_table_name, $row_name)
{
  include 'mysql.php';
  $sql = "SELECT MAX($row_name) AS Largest FROM $_table_name";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
          $value=$row["Largest"];
      }
  } else {
      echo "0 results";
  }
  return $value;
}
public function student_detail()
{
  $val=$this->max_cont("student","st_id");
  $rows_name=["student_id","semester","course","program"];
  $row_value[0]=$val;
 $row_value[1]=$_GET['sem'];
  $row_value[2]=$_GET['course'];
  $row_value[3]=$_GET['program'];
  $this->sql_query_builder("student_detail",$rows_name,$row_value);
  $this->sql_added_to_table();

}

}

if (isset($_GET['type'])) {
    $create = new create_table;
  if ($_GET['type']=="create") {
    if ($_GET['table_name']=="Dashboard") {
      $row_name=["deptname"];
      $row_value[0]=strtoupper($_GET['department_name']) ;
      $create->sql_query_builder("department",$row_name,$row_value);
      $create->sql_added_to_table();
    }
    if ($_GET['table_name']=="Exam_hall") {
      $row_name=["hall_no","capacity"];
      $row_value[0]=$_GET['hall_no'];
      $row_value[1]=$_GET['capacity'];
      $create->sql_query_builder("examhall",$row_name,$row_value);
      $create->sql_added_to_table();
    }
        if ($_GET['table_name']=="program") {
          $val=$create->max_cont("program","pgrmid");
          $row_name=["prgmname","deptid","pgrmid"];
          $row_value[0]=strtoupper($_GET['program_name']);
          $row_value[1]=$_GET['department_id'];
          $val=$val+1;
          $row_value[2]=$val;
          $create->sql_query_builder("program",$row_name,$row_value);
          $create->sql_added_to_table();
        }
                if ($_GET['table_name']=="time_table") {
                  $row_name=["pcode","exam_date","time"];
                  $row_value[0]=$_GET['timetable'];
                  $row_value[1]=$_GET['exam_date'];
                  $row_value[2]=$_GET['Time'];
                    $create->sql_query_builder("timetable",$row_name,$row_value);
                    $create->sql_added_to_table();
                }
                if ($_GET['table_name']=="course") {
                  $row_name=["pcode","pgrmid","semester","batch"];
                  $row_value[0]=strtoupper($_GET['paper_code']);
                  $row_value[1]=$_GET['programid'];
                  $row_value[2]=$_GET['semester'];
                  $row_value[3]=$_GET['batch'];
                  $create->sql_query_builder("course",$row_name,$row_value);
                  $create->sql_added_to_table();
                }
                if ($_GET['table_name']=="student_reg") {
                 $row_name=["student_name"];
                  $row_value[0]=$_GET['student_name'];
                  $create->sql_query_builder("student",$row_name,$row_value);
                 $create->sql_added_to_table();
                     $create2 = new create_table;
                  $create2->student_detail();
                }
                if ($_GET['table_name']=="course_student_adder") {
                 $row_name=["semester","course","program","student_id"];
                  $row_value[0]=$_GET['sem'];
                  $row_value[1]=$_GET['course'];
                  $row_value[2]=$_GET['program'];
                  $row_value[3]=$_GET['student_id'];
                  $create->sql_query_builder("student_detail",$row_name,$row_value);
                 $create->sql_added_to_table();
                }
  }

}

 ?>
