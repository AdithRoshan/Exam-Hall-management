<?php
function option_change_table()
{
  include 'mysql.php';
  $sql = "SELECT * FROM program LEFT JOIN department ON  program.deptid=department.dpt_id WHERE prgmname='$_GET[val]' ";
  $result = $conn->query($sql);

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
        echo '<option value="'.$row['deptname'].'">'.$row['deptname'].'</option>  ';
    }
    echo "</select>";
} else {
    echo "0 results";
}
}
if (isset($_GET['type'])) {
  if ($_GET['type']=="student") {
    option_change_table();
  }
}

 ?>
