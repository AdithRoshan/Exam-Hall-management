<!DOCTYPE html>
<?php include 'mysql.php';
$sql = "SELECT * FROM timetable";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<label for="">Exam Paper Code</label>
<select class="" name="papercode" id='papercode' onchange="show_historys(this.value)">
  <option value="NULL">Choose the Options</option>
  <?php  while($row = $result->fetch_assoc()) { ?>
  <option value="<?php echo $row['pcode']; ?>"
     ><?php echo $row['pcode']; ?></option>
  <?php     }
} else {
    echo "0 results";
} ?>
</select>
<div class="" id="sector_show_history">

</div>
  </body>
</html>
