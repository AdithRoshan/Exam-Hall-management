<?php
class seat_arragment
{
  public function query_insert_to_sql($my_sql_querry_txt,$row_name)
  {
    include 'mysql.php';
    $sql = $my_sql_querry_txt;
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
      $id_name = array();
      $count=0;
    while($row = $result->fetch_assoc()) {
       $id_name[$count]=$row[$row_name];
       $count++;
    }
} else {
  //  echo "0 results";
}
return $id_name;
  }

  public function sql_query_builder_single($table_name,$row_name,$where_name=NULL,$where_type="OR",$where_value=NULL)
  {
    $my_sql_querry_txt="SELECT * FROM ";
    $my_sql_querry_txt=$my_sql_querry_txt.$table_name;
    if ($where_name!=NULL) {
      $my_sql_querry_txt=$my_sql_querry_txt." WHERE ".$where_name[0]." = ".$where_value[0];
      for ($i=1; $i < count($where_name) ; $i++) {
        $my_sql_querry_txt=$my_sql_querry_txt." ".$where_type;
        $my_sql_querry_txt=$my_sql_querry_txt." ".$where_name[$i]." = ".$where_value[$i];
      }
    }
    $row_value=$this->query_insert_to_sql($my_sql_querry_txt,$row_name);
  // echo $my_sql_querry_txt;
    return $row_value;
  }
  public function sql_query_builder_multiple($table_name_list,$join_condition,$row_name,$where_name=NULL,$where_type="OR",$where_value=NULL)
  {
      $my_sql_querry_txt="SELECT * FROM ".$table_name_list[0];
      for ($i=1; $i < count($table_name_list); $i++) {
        $my_sql_querry_txt=$my_sql_querry_txt." LEFT JOIN ".$table_name_list[$i]." ON ".$join_condition[$i-1];
      }
      if ($where_name!=NULL) {
        $my_sql_querry_txt=$my_sql_querry_txt." WHERE ".$where_name[0]." = ".$where_value[0];
        for ($i=1; $i <count($where_value) ; $i++) {
          $my_sql_querry_txt=$my_sql_querry_txt." ".$where_type." ".$where_name[$i]." = ".$where_value[$i];
        }
      }
    //  echo $my_sql_querry_txt;
        $row_value=$this->query_insert_to_sql($my_sql_querry_txt,$row_name);
        return $row_value;
  }

  public function student_name_select($row_value,$sem,$batch,$program,$department)
  {
        include 'mysql.php';
        $sql = "SELECT * FROM student LEFT JOIN student_detail ON student.st_id = student_detail.student_id WHERE semester = $sem  AND course ='$program' AND program = '$department' ";
        //echo $sql;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $count=0;
    while($row = $result->fetch_assoc()) {
      $row_val[$count]=$row[$row_value];
    //    echo $row_val[$count];
        $count++;
    }
    return $row_val;
} else {
    //echo "0 results";
    return NULL;
}

  }
  public function insert_values_to_tables($table_name,$insert_hall_id,$insert_student_id)
  {
      include 'mysql.php';
    $sql = "INSERT INTO $table_name (hall_id, student_id, date, time)
VALUES ($insert_hall_id , $insert_student_id, '$_GET[date]','$_GET[time]')";
if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
} else {
  //  echo "Error: " . $sql . "<br>" . $conn->error;
}
  }
}

$arrange = new seat_arragment;
error_reporting(0);
$table_name ="timetable";
$where_name = array("exam_date", "time") ;
$where_type = "AND" ;
$date ="'".$_GET['date']."'";
$time ="'".$_GET['time']."'";
$where_value=array($date,$time);
$row_name="pcode";
$paper_codes=$sql_query_value=$arrange->sql_query_builder_single($table_name,$row_name,$where_name,$where_type,$where_value);
//echo $paper_codes[1];
if ($paper_codes[0]!=NULL) {
  $table_name_list=array("course","program","department");
  $where_name=array("pcode","pcode");
        $pcode = array();
  for ($i=0; $i < count($paper_codes); $i++) {
      $pcode[$i]="'".$paper_codes[$i]."'";
  }
  for ($i=0; $i < count($paper_codes); $i++) {
    $where_name[$i]="pcode";
  }
  $where_type="OR";
  $row_name="semester";
  $join_condition= array("course.pgrmid = program.pgrmid","program.deptid = department.dpt_id");
  $sem=$arrange->sql_query_builder_multiple($table_name_list,$join_condition,$row_name,$where_name,$where_type,$pcode);
  //echo $sem[1];
    $row_name="batch";
    $batch=$arrange->sql_query_builder_multiple($table_name_list,$join_condition,$row_name,$where_name,$where_type,$pcode);
    //echo $batch[0];
    $row_name="prgmname";
    $programes=$arrange->sql_query_builder_multiple($table_name_list,$join_condition,$row_name,$where_name,$where_type,$pcode);
    //echo $programes[1];
    $row_name="deptname";
    $department=$arrange->sql_query_builder_multiple($table_name_list,$join_condition,$row_name,$where_name,$where_type,$pcode);
    //echo $department[1];
    $student_id = array();
    $j=0;
    for ($i=0; $i < count($department); $i++) {
      $sem_name_pass=$sem[$i];
      $batch_name_pass=$batch[$i];
      $program_name_pass=$programes[$i];
      $department_name_pass=$department[$i];
      $row_value="st_id";
      $arr_temp=$arrange->student_name_select($row_value,$sem_name_pass,$batch_name_pass,$program_name_pass,$department_name_pass);
      for ($x=0; $x < count($arr_temp); $x++) {
        $student_id[$j] = $arr_temp[$x];
        $j++;
      }
    }
        // print_r($student_id);
        $table_name="examhall";
        $row_name= "exam_hall_id";
        $hall_room_number_id=$arrange->sql_query_builder_single($table_name,$row_name);
        //print_r($hall_room_number_id);
        $table_name="examhall";
        $row_name= "hall_no";
        $hall_room_number=$arrange->sql_query_builder_single($table_name,$row_name);
        //print_r($hall_room_number);
        $table_name="examhall";
        $row_name= "capacity";
        $hall_room_capacity=$arrange->sql_query_builder_single($table_name,$row_name);
        //print_r($hall_room_capacity);
        $total_capacity=0;
        for ($i=0; $i < count($hall_room_capacity); $i++) {
          settype($hall_room_capacity[$i], "integer");
          $total_capacity=$total_capacity+$hall_room_capacity[$i];
                //    echo $total_capacity;
        }
      //  echo $total_capacity;
      if (count($student_id)<$total_capacity) {
        if (count($programes)>1) {

          //echo "You have more than one exam today";
          $student_left=count($student_id);
        //  echo "<br>";
          //echo count($student_id);
          $t=0;
          $top=0;
          $left_over_student_count=count($student_id);
          for ($i=0; $student_left >= 0; $i++) {
            if ($i >= count($hall_room_capacity)) {
              $i=0;
            }
            if ($top<count($student_id)) {

                          $student_left--;
                          $table_name="seat_formation";
                          $insert_hall_id=$hall_room_number_id[$i];
                          for ($z=0; $z < $hall_room_capacity[$i]/3; $z++) {
                            $insert_student_id=$student_id[$top];
                            $arrange->insert_values_to_tables($table_name,$insert_hall_id,$insert_student_id);
                            $top++;
                            $hall_room_capacity[$i]=$hall_room_capacity[$i]-1;
                            $student_left--;
                            $left_over_student_count--;
                          }

}
          }
        }else {

          echo "you have only one exam today";
        }
      }else {
        echo "This is no room to hold this much student";
      }

}else {
  echo "Thiers is no paper in this time or date";
}
 ?>
