<!DOCTYPE html>
<?php
session_start();
if (isset($_SESSION["user"])) {
  //
}else {
  header('location:index.php');
}

 ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>EXAM REGISTORY</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/mian.css">
  </head>
  <script type="text/javascript">
   var head_name=["dpt_id","deptname"];
    var table_name=["department"];
      var table_alter_head_name=["Id","department"];
      var create_names=["department name"];
      var create_head_name=["deptname"];
  </script>
  <body>
    <?php include 'attach_file/nav_head_bar.php'; ?>
<?php include 'attach_file/nav.php'; ?>
<div class="" id="custom_formation" style="position:absolute; top:-2000px; transition:1s; background-color:white; width:80%; padding:10px;">

</div>
<script type="text/javascript">
function select_option_checkbox(id_name) {
console.log(id_name);
var url_name="attach_file/attendance_selection.php?date="+document.getElementById("arragement_date1").value;
url_name=url_name+"&time="+document.getElementById("time1").value;
url_name=url_name+"&hall_no="+document.getElementById("room_number").value;
url_name=url_name+"&roll_number="+id_name;
console.log(url_name);
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    document.getElementById("create_status4").innerHTML =
    this.responseText;
  }
};
xhttp.open("GET", url_name, true);
xhttp.send();
}
function custom_formation() {
  document.getElementById('custom_formation').style.top="50px";
  var url_name="attach_file/custom_formation_form.php";
  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("custom_formation").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
function cust_form() {
  document.getElementById('custom_formation').style.top="-20000px";
}
</script>
<script type="text/javascript">
function selectbar_change(selector_name) {
  var url_name="attach_file/onchange.php?type=student&val="+document.getElementById('program').value;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("department").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
</script>
<div class="model" id="update_exam_date">
  <div class=""id="update_exam_date_selector">

  </div>
</div>
<div class="model" id="exam_history_model">
  <div class="right btn_sign_out" onclick="History_close()">
    Close
  </div>
  <div class=""id="exam_history_model_sector">

  </div>
</div>
<div class="model" id="formation_print_model">
  <div class=""id="atteandence_formation_printout">

  </div>
</div>
<div class="model" id="print_formation">
<p id="model_head_txt">Print:</p>
<div class="right btn_sign_out" onclick="print_close()">
  Close
</div>
<form  action="print.php" method="get">
<label for="">Date</label>
<input type="date" name="date" value="">
<label for="">Time</label>
<select id="time" name="time">
  <option value="FN">FN</option>
  <option value="AN">AN</option>
</select>
<button type="submit" name="button">Submit</button>
</form>
</div>



<div class="model" id="model2">
<p id="model_head_txt">Arrangement:</p>
<div class="right btn_sign_out" onclick="seatarragment_close()">
  Close
</div>
<div class="" id="model_inputs2">
<input type="date" name="" value="" id="arragement_date">
<br>
<label for="">Time</label>
<select id="time">
  <option value="FN">FN</option>
  <option value="AN">AN</option>
</select>
</div>




<div class="" id="create_status2">

</div>
<button type="button" name="button" onclick="create_seat_arragment()">Submit</button>
</div>

<div class="model" id="model3">
<p id="model_head_txt">Attendance:</p>
<div class="right btn_sign_out" onclick="attendance_close()">
  Close
</div>
<div class="" id="model_inputs2">
<input type="date" name="" value="" id="arragement_date1">
<br>
<label for="">Time</label>
<select id="time1">
  <option value="FN">FN</option>
  <option value="AN">AN</option>
</select>
</div>
<div class="" id="option_hall3">

</div>
<div class="" id="create_status3">

</div>
<div class="" id="create_status4">

</div>
<button type="button" name="button" onclick="attendance_room_option()">Submit</button>
</div>

<div class="model" id="model1">
<p id="model_head_txt">ADDER:</p>
<div class="right btn_sign_out" onclick="course_adder_close()">
  Close
</div>
<div class="" id="model_inputs1">

</div>
<div class="" id="create_status1">

</div>
</div>
      <div class="round" onclick="model()" id="round">+</div>
<div class="right table_view_box">
  <?php
  if (isset($_GET['report'])) {
    echo $_GET['report'].' for custom examination';
  } ?>
    <div id="table">  </div>
    </div>
    <div class="model" id="model">
    <p id="model_head_txt">CREATE:</p>
    <div class="" id="model_inputs">

    </div>
    <div class="" id="create_status">

    </div>
    </div>



<script>
var registor_url_table;
function registor_temp(url){
registor_url_table=url;
//console.log(registor_url_table);
}
function registor_table_call() {
console.log(registor_url_table);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("table").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", registor_url_table, true);
  xhttp.send();
}
//function for loading XMLHttpRequest for creating every table veiw
function loadDoc(table_para) {
  var url_name="attach_file/table.php?type=table";
  for (var i = 0; i < table_para.head_names.length; i++) {
    url_name+="&table_head[]="+table_para.head_names[i];
  }
  for (var i = 0; i < table_para.table_alter_head_name.length; i++) {
    url_name+="&table_alter_head_name[]="+table_para.table_alter_head_name[i];
  }
  if (typeof table_para.joint_parameters != "undefined") {
    for (var i = 0; i < table_para.joint_parameters.length; i++) {
      url_name+="&table_joint_parameter[]="+table_para.joint_parameters[i];
    }
  }
      if (typeof table_para.table_namelist != "undefined") {
  for (var i = 0; i < table_para.table_namelist.length; i++) {
    url_name+="&table_name_list[]="+table_para.table_namelist[i];
  }
}else {
  url_name+="&table_name="+table_para.table_name;
}
registor_temp(url_name);
  //console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("table").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
loadDoc({head_names: head_name,table_name: table_name, table_alter_head_name: table_alter_head_name });
</script>
<script type="text/javascript">
function create_table(table_name,button_type=0,id_no=0) {
console.log(button_type);
  if (button_type!=0) {
    var url_name="attach_file/edit_table.php?type=edit&table_name="+table_name+"&id_no="+id_no+"&button_type="+button_type;
  }else {
      var url_name="attach_file/create_table.php?type=create&table_name="+table_name;
  }
if (table_name=="Dashboard") {
  url_name=url_name+"&department_name="+document.getElementById("department_name").value;
}
if (table_name=="Exam_hall") {
  url_name=url_name+"&hall_no="+document.getElementById("hall_no").value;
    url_name=url_name+"&capacity="+document.getElementById("capacity").value;
}
if (table_name=="program") {
  url_name=url_name+"&program_name="+document.getElementById("program_name").value;
  url_name=url_name+"&department_id="+document.getElementById("department").value;
}
if (table_name=="course") {
  url_name=url_name+"&paper_code="+document.getElementById("paper_code").value;
  url_name=url_name+"&semester="+document.getElementById("semester").value;
  url_name=url_name+"&batch="+document.getElementById("batch").value;
    url_name=url_name+"&programid="+document.getElementById("program").value;
  //url_name=url_name+"&department="+document.getElementById("department").value;
}
if (table_name=="time_table") {
  url_name=url_name+"&exam_date="+document.getElementById("exam_date").value;
  url_name=url_name+"&Time="+document.getElementById("Time").value;
  url_name=url_name+"&timetable="+document.getElementById("course").value;
}
if (table_name=="student_reg") {
  url_name=url_name+"&student_name="+document.getElementById("student_name").value;
    url_name=url_name+"&sem="+document.getElementById("course").value;
      url_name=url_name+"&course="+document.getElementById("program").value;
        url_name=url_name+"&program="+document.getElementById("department").value;
}
if (table_name=="course_student_adder") {
  url_name=url_name+"&student_id="+document.getElementById("student_id").value;
    url_name=url_name+"&sem="+document.getElementById("course").value;
      url_name=url_name+"&course="+document.getElementById("program").value;
        url_name=url_name+"&program="+document.getElementById("department").value;
}
  console.log(url_name);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("create_status").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", url_name, true);
  xhttp.send();
}
</script>
<script src="js/main.js" charset="utf-8"></script>

  </body>
</html>
