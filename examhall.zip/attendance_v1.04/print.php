<!DOCTYPE html>
<?php
function print_table($hall_no)
{
	include 'attach_file/mysql.php';
	$sql = "SELECT * FROM seat_formation LEFT JOIN  student_detail ON seat_formation.student_id = student_detail.student_id LEFT JOIN
	examhall ON seat_formation.hall_id = examhall.exam_hall_id LEFT JOIN program ON student_detail.course =  program.prgmname LEFT JOIN department ON student_detail.program = department.deptname LEFT JOIN course ON student_detail.semester = course.semester AND program.pgrmid =course.pgrmid WHERE seat_formation.date ='$_GET[date]' AND seat_formation.hall_id=$hall_no ORDER BY program.prgmname  ";
//echo $sql;
$result = $conn->query($sql);
	if ($result->num_rows > 0) {?>
		<table>
			<tr>
				<td>Reg.No</td>
					<td>Main Answer books</td>
						<td>Addl.Answer
						bokks</td>
							<td>Signature of the Candinate</td>
			</tr>

	<?php   $j=0;
	 while($row = $result->fetch_assoc()) {
		if ($j==0) {
			$pcode_no=$row["prgmname"];
			?>
			<tr>
			 <td><?php echo  $row["prgmname"];?></td>
			 <td></td>
			 <td></td>
			 <td></td>
			</tr>
	<?php	$j++;
}
if ($pcode_no==$row["prgmname"]) {
	echo "	<tr>";
echo "<td>".$row["student_id"]."</td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "</tr>";
}else {
	echo "	<tr>";
echo "<td>".$row["prgmname"]."</td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "</tr>";
echo "	<tr>";
echo "<td>".$row["student_id"]."</td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "</tr>";
$pcode_no=$row["prgmname"];
}
	     //  echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>"; ?>

		<?php    } ?>	</table><?php
	} else {
	    echo "0 results";
	}
}
 ?>
<?php
include 'attach_file/mysql.php';
$sql = "SELECT DISTINCT hall_id,hall_no  FROM seat_formation LEFT JOIN  student_detail ON seat_formation.student_id = student_detail.student_id LEFT JOIN
examhall ON seat_formation.hall_id = examhall.exam_hall_id LEFT JOIN program ON student_detail.course =  program.prgmname LEFT JOIN department ON student_detail.program = department.deptname LEFT JOIN course ON student_detail.semester = course.semester AND program.pgrmid =course.pgrmid WHERE seat_formation.date ='$_GET[date]' ORDER BY hall_id DESC  ";
//echo $sql;
$result = $conn->query($sql);
?>

<html>
<head>
	<title>HTML to PDF</title>
</head>
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/mian.css">
<body>

	<div id="HTMLtoPDF">

	<h2>ABC UNIVERSITY</h2>
	<h4>Date of Examination:  <?php echo $_GET['date']; ?> </h4>
	<h4>Center of Examination: ABC college</h4>
<?php
		$hall_no = array();
				$hall_no_id = array();
		 if ($result->num_rows > 0) {
$i=0;
    while($row = $result->fetch_assoc()) {
$hall_no[$i]=$row["hall_id"];
$hall_no_id[$i]=$row["hall_no"];
$i++;
			//echo "temp=".$temp_hall_no;echo "<br>";
    }
} else {
    echo "0 results";
} ?>

<?php
	$j=0;
for ($i=0; $i < count($hall_no); $i++) {
	echo "<br>";
	echo "<br>";?>
	<table>
		<tr>
			<td>Hall No: <?php echo $hall_no_id[$i];   ?></td>
		</tr>
	</table>
	<?php
//echo $hall_no[$i]; echo "<br>";
//echo "Hall No: ";
//echo $hall_no_id[$i]; echo "<br>";
echo "<br>";
echo "<br>";
print_table($hall_no[$i]);
}


 ?>
	</div>

	<a href="#" onclick="HTMLtoPDF()">Download PDF</a>

	<script src="js/jspdf.js"></script>
	<script src="js/jquery-2.1.3.js"></script>
	<script src="js/pdfFromHTML.js"></script>
</body>
</html>
